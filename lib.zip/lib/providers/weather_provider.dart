import 'package:flutter/material.dart';
import 'package:weather_app/models/weather_model.dart';
import 'package:weather_app/services/weather_service.dart';
import 'package:weather_app/services/local_storage_service.dart';

/// 🟢 États possibles du WeatherProvider
enum WeatherState { initial, loading, loaded, error }

/// 🟢 WeatherProvider — Gestion de l’état météo + favoris
/// ⚡ Permet de rechercher la météo, gérer les favoris et notifier l’UI
class WeatherProvider extends ChangeNotifier {
  // 🟢 Service REST pour récupérer la météo
  final WeatherService _weatherService = WeatherService();

  // 🟢 Service de stockage local pour gérer les favoris
  final LocalStorageService _storageService = LocalStorageService();

  // 🟢 Météo actuelle affichée
  Weather? _currentWeather;

  // 🟢 Liste des favoris
  List<Weather> _favorites = [];

  // 🟢 État courant du provider
  WeatherState _state = WeatherState.initial;

  // 🟢 Message d’erreur
  String? _error;

  // 🟢 Indicateur de chargement pour l’UI
  bool _isLoading = false;

  // 🟢 Getters
  Weather? get currentWeather => _currentWeather;
  List<Weather> get favorites => _favorites;
  WeatherState get state => _state;
  bool get isLoading => _isLoading;
  String? get error => _error;
  bool get hasError => _error != null;

  /// 🟢 Constructeur — charge les favoris au démarrage
  WeatherProvider() {
    _loadFavorites();
  }

  /// 🟢 Charge les favoris depuis le stockage local
  void _loadFavorites() {
    try {
      _favorites = _storageService.getFavorites();
      notifyListeners(); // 🟢 Notifie l’UI
    } catch (e) {
      _error = 'Failed to load favorites';
    }
  }

  /// 🟢 Recherche la météo d’une ville
  Future<void> searchWeather(String city) async {
    if (city.trim().isEmpty) {
      _error = 'Please enter a city name';
      _state = WeatherState.error;
      notifyListeners();
      return;
    }

    _isLoading = true;
    _state = WeatherState.loading;
    _error = null;
    notifyListeners();

    try {
      final weather = await _weatherService.getWeatherByCity(city.trim());
      _currentWeather = weather;
      _state = WeatherState.loaded;
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      _state = WeatherState.error;
      _isLoading = false;
      notifyListeners();
    }
  }

  /// 🟢 Ajoute une ville aux favoris
  Future<void> addFavorite(Weather weather) async {
    try {
      await _storageService.addFavorite(weather);
      _favorites = _storageService.getFavorites();
      notifyListeners();
    } catch (e) {
      _error = 'Failed to add favorite';
      notifyListeners();
    }
  }

  /// 🟢 Supprime une ville des favoris
  Future<void> removeFavorite(String city) async {
    try {
      await _storageService.removeFavorite(city);
      _favorites = _storageService.getFavorites();
      notifyListeners();
    } catch (e) {
      _error = 'Failed to remove favorite';
      notifyListeners();
    }
  }

  /// 🟢 Vérifie si une ville est dans les favoris
  bool isFavorite(String city) {
    try {
      return _storageService.isFavorite(city);
    } catch (e) {
      return false;
    }
  }

  /// 🟢 Charge la météo d’une ville favorite
  Future<void> loadFavoriteWeather(String city) async {
    _isLoading = true;
    _state = WeatherState.loading;
    _error = null;
    notifyListeners();

    try {
      final weather = await _weatherService.getWeatherByCity(city);
      _currentWeather = weather;
      _state = WeatherState.loaded;
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      _state = WeatherState.error;
      _isLoading = false;
      notifyListeners();
    }
  }

  /// 🟢 Efface le message d’erreur
  void clearError() {
    _error = null;
    notifyListeners();
  }

  /// 🟢 Efface la météo actuelle et remet l’état à initial
  void clearCurrentWeather() {
    _currentWeather = null;
    _state = WeatherState.initial;
    notifyListeners();
  }
}
