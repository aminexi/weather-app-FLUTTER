import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import '../models/weather_model.dart';

/// 🟢 Exception personnalisée pour la gestion des erreurs météo
class WeatherException implements Exception {
  final String message; // 🟢 Message d’erreur lisible
  final String? code; // 🟢 Code d’erreur optionnel (ex: NETWORK, TIMEOUT)

  WeatherException(this.message, {this.code});

  @override
  String toString() => message;
}

/// 🟢 Service pour récupérer la météo depuis l’API WeatherAPI
/// ⚡ Supporte cache interne pour éviter des appels répétés
class WeatherService {
  // 🟢 URL de base de l’API
  static const String _baseUrl = 'http://api.weatherapi.com/v1/current.json';

  // 🟢 Clé API pour authentification auprès du service météo
  static const String _apiKey = 'f19c165f74fb4198805212448251710';

  // 🟢 Timeout pour les requêtes HTTP
  static const Duration _timeout = Duration(seconds: 10);

  // 🟢 Cache en mémoire pour stocker les résultats récents
  final Map<String, Weather> _cache = {};
  final Map<String, DateTime> _cacheTime = {};

  // 🟢 Durée de validité du cache
  static const Duration _cacheDuration = Duration(minutes: 10);

  /// 🟢 Nettoie le cache des entrées expirées
  void _cleanCache() {
    final now = DateTime.now();

    // 🟢 Supprime les clés dont le cache a expiré
    _cacheTime
        .removeWhere((key, time) => now.difference(time) > _cacheDuration);

    // 🟢 Supprime les données associées dans _cache
    _cache.removeWhere((key, _) => !_cacheTime.containsKey(key));
  }

  /// 🟢 Récupère la météo d’une ville par son nom
  Future<Weather> getWeatherByCity(String city) async {
    if (city.trim().isEmpty) {
      throw WeatherException('City name cannot be empty');
    }

    _cleanCache();
    final key = city.toLowerCase();

    // 🟢 Retourne la météo depuis le cache si disponible
    if (_cache.containsKey(key)) {
      return _cache[key]!;
    }

    try {
      // 🟢 Requête HTTP vers WeatherAPI
      final response = await http
          .get(Uri.parse('$_baseUrl?key=$_apiKey&q=$city'))
          .timeout(_timeout);

      return _handleResponse(response, key);
    } on http.ClientException catch (e) {
      throw WeatherException('Network error: ${e.message}', code: 'NETWORK');
    } on TimeoutException {
      throw WeatherException('Request timed out', code: 'TIMEOUT');
    } catch (e) {
      throw WeatherException('Unexpected error: $e', code: 'UNKNOWN');
    }
  }

  /// 🟢 Récupère la météo par latitude et longitude
  Future<Weather> getWeatherByCoordinates(
      double latitude, double longitude) async {
    // 🟢 Vérification de la validité des coordonnées
    if (latitude < -90 ||
        latitude > 90 ||
        longitude < -180 ||
        longitude > 180) {
      throw WeatherException('Invalid coordinates');
    }

    final cacheKey = '${latitude}_$longitude';
    _cleanCache();

    // 🟢 Retourne depuis le cache si disponible
    if (_cache.containsKey(cacheKey)) return _cache[cacheKey]!;

    try {
      final response = await http
          .get(Uri.parse('$_baseUrl?key=$_apiKey&q=$latitude,$longitude'))
          .timeout(_timeout);

      return _handleResponse(response, cacheKey);
    } on http.ClientException catch (e) {
      throw WeatherException('Network error: ${e.message}', code: 'NETWORK');
    } on TimeoutException {
      throw WeatherException('Request timed out', code: 'TIMEOUT');
    } catch (e) {
      throw WeatherException('Unexpected error: $e', code: 'UNKNOWN');
    }
  }

  /// 🟢 Analyse la réponse HTTP et convertit en Weather
  Weather _handleResponse(http.Response response, String cacheKey) {
    if (response.statusCode == 200) {
      final weather = Weather.fromJson(jsonDecode(response.body));

      // 🟢 Sauvegarde dans le cache
      _cache[cacheKey] = weather;
      _cacheTime[cacheKey] = DateTime.now();
      return weather;
    } else if (response.statusCode == 401) {
      throw WeatherException('Invalid API key', code: 'UNAUTHORIZED');
    } else if (response.statusCode == 404) {
      throw WeatherException('City not found', code: 'NOT_FOUND');
    } else if (response.statusCode == 429) {
      throw WeatherException('Rate limit exceeded', code: 'RATE_LIMIT');
    } else {
      throw WeatherException(
          'Failed to fetch weather (Status: ${response.statusCode})',
          code: 'HTTP_ERROR');
    }
  }

  /// 🟢 Vide complètement le cache en mémoire
  void clearCache() {
    _cache.clear();
    _cacheTime.clear();
  }
}
