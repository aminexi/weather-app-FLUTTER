class Weather {
  final String city;
  final double temperature;
  final String description;
  final double feelsLike;
  final int humidity;
  final double windSpeed;
  final String icon;
  final int pressure;
  final int visibility;
  final double uvIndex;
  final DateTime timestamp;

  Weather({
    required this.city,
    required this.temperature,
    required this.description,
    required this.feelsLike,
    required this.humidity,
    required this.windSpeed,
    required this.icon,
    this.pressure = 0,
    this.visibility = 0,
    this.uvIndex = 0.0,
    DateTime? timestamp,
  }) : timestamp = timestamp ?? DateTime.now();

  Weather copyWith({
    String? city,
    double? temperature,
    String? description,
    double? feelsLike,
    int? humidity,
    double? windSpeed,
    String? icon,
    int? pressure,
    int? visibility,
    double? uvIndex,
    DateTime? timestamp,
  }) {
    return Weather(
      city: city ?? this.city,
      temperature: temperature ?? this.temperature,
      description: description ?? this.description,
      feelsLike: feelsLike ?? this.feelsLike,
      humidity: humidity ?? this.humidity,
      windSpeed: windSpeed ?? this.windSpeed,
      icon: icon ?? this.icon,
      pressure: pressure ?? this.pressure,
      visibility: visibility ?? this.visibility,
      uvIndex: uvIndex ?? this.uvIndex,
      timestamp: timestamp ?? this.timestamp,
    );
  }

  factory Weather.fromJson(Map<String, dynamic> json) {
    try {
      final location = json['location'];
      final current = json['current'];
      return Weather(
        city: location['name'] ?? 'Unknown',
        temperature: (current['temp_c'] ?? 0).toDouble(),
        description: current['condition']['text'] ?? 'Unknown',
        feelsLike: (current['feelslike_c'] ?? 0).toDouble(),
        humidity: current['humidity'] ?? 0,
        windSpeed: (current['wind_kph'] ?? 0).toDouble(),
        icon: current['condition']['icon'] ?? '',
        pressure: (current['pressure_mb'] ?? 0).toInt(),
        visibility: ((current['vis_km'] ?? 0).toDouble()).toInt(),
        uvIndex: (current['uv'] ?? 0).toDouble(),
      );
    } catch (e) {
      throw FormatException('Failed to parse weather data: $e');
    }
  }

  Map<String, dynamic> toMap() {
    return {
      'city': city,
      'temperature': temperature,
      'description': description,
      'feelsLike': feelsLike,
      'humidity': humidity,
      'windSpeed': windSpeed,
      'icon': icon,
      'pressure': pressure,
      'visibility': visibility,
      'uvIndex': uvIndex,
      'timestamp': timestamp.toIso8601String(),
    };
  }

  factory Weather.fromMap(Map<String, dynamic> map) {
    return Weather(
      city: map['city'] ?? 'Unknown',
      temperature: (map['temperature'] ?? 0).toDouble(),
      description: map['description'] ?? 'Unknown',
      feelsLike: (map['feelsLike'] ?? 0).toDouble(),
      humidity: map['humidity'] ?? 0,
      windSpeed: (map['windSpeed'] ?? 0).toDouble(),
      icon: map['icon'] ?? '',
      pressure: map['pressure'] ?? 0,
      visibility: map['visibility'] ?? 0,
      uvIndex: (map['uvIndex'] ?? 0).toDouble(),
      timestamp: map['timestamp'] != null
          ? DateTime.parse(map['timestamp'])
          : DateTime.now(),
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is Weather &&
          runtimeType == other.runtimeType &&
          city == other.city &&
          temperature == other.temperature;

  @override
  int get hashCode => city.hashCode ^ temperature.hashCode;

  @override
  String toString() =>
      'Weather(city: $city, temp: $temperature°C, desc: $description)';
}
